#' Sample the empty cells data
#'
#' This function generate the empty-cell samples
#' 
#' 
#' @param UqC 
#' @param N
#' @export
#' @examples
#' \dontrun{
#' sample.empty<- function(UqC,N)
#' }


sample.empty<- function(UqC,N,colnumber){
  if(missing(UqC)) {ncol=colnumber;ext=NULL} else 
  {
    ncol <- ncol(UqC)
    ext <- apply(UqC,1,function (x) 
    {
      sum(x*2^((ncol-1):0))
    }
    )
    
  }
temp.N=0
sample.now <- NULL
out <- NULL
while (temp.N < N)
{
temp <-  matrix(sample(2,ncol*N,replace=TRUE)-1,ncol=ncol)

if (is.null(ext)) out <- rbind(out,temp) else 
  {
    sample.now <-apply(temp,1,function(x) sum(x*2^((ncol-1):0)))
    out <- rbind(out,temp[!sample.now%in%ext,])
  }
temp.N = nrow(out)
}
out
}
